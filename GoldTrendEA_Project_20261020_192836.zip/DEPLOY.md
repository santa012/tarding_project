﻿# How to deploy this on another machine

1. Unzip this archive anywhere on the new machine.
2. Open PowerShell AS ADMINISTRATOR in the unzipped folder.
3. Run:
     cd dashboard
     powershell -ExecutionPolicy Bypass -File .\setup.ps1
   This installs WSL2 + Docker Desktop if missing, auto-detects the local
   MT5 terminal's log folder, and starts the dashboard at
   http://localhost:8080

   If WSL2 had to be installed fresh, Windows will require a reboot - the
   script tells you this clearly. Reboot, then run the same command again.

4. MQL5 EAs/scripts are under .\MQL5\Experts\GoldTrendEA and .\MQL5\Scripts.
   Copy them into the new machine's MT5 data folder
   (MT5 -> File -> Open Data Folder -> MQL5\Experts / MQL5\Scripts),
   then compile each one in MetaEditor (F7) before using it.
