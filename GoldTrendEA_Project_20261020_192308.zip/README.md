# GoldTrendEA

Expert Advisor (EA) สำหรับ MetaTrader 5 เทรดทอง (XAUUSD / GOLD) แบบ trend following บน H1

## ภาษาที่ใช้

**MQL5** (MetaQuotes Language 5) เป็นภาษาของ MetaTrader 5 โดยตรง
หน้าตาและไวยากรณ์คล้าย **C++** (มี class, pointer, template, `#include`)
ไฟล์ซอร์สคือ `.mq5` และเมื่อคอมไพล์จะได้ไฟล์ `.ex5` ที่ MT5 ใช้รันจริง

> MT4 ใช้ MQL4 ซึ่งเป็นคนละภาษา โค้ดชุดนี้ใช้กับ MT4 ไม่ได้

## โครงสร้างโปรเจกต์

```
GoldTrendEA_Project/
├── README.md
└── MQL5/
    └── Experts/
        └── GoldTrendEA/
            └── GoldTrendEA.mq5      <- ซอร์สโค้ดหลัก
```

โครงโฟลเดอร์ `MQL5/Experts/...` ตรงกับโฟลเดอร์ข้อมูลของ MT5 จึงคัดลอกทับได้เลย

## วิธีติดตั้ง

1. เปิด MT5 -> เมนู **File -> Open Data Folder**
2. คัดลอกโฟลเดอร์ `GoldTrendEA` ไปวางที่ `MQL5/Experts/`
3. เปิด MetaEditor (กด **F4** ใน MT5) เปิดไฟล์ `GoldTrendEA.mq5` แล้วกด **F7** เพื่อคอมไพล์ (ต้องไม่มี error)
4. กลับไป MT5 กด Refresh ที่ Navigator แล้วลาก EA ไปวางบนกราฟทอง
5. เปิดปุ่ม **Algo Trading** ที่แถบบน และติ๊ก "Allow Algo Trading" ในหน้าต่าง EA

### ถ้าอยากให้เป็น Project ใน MetaEditor (.mqproj)

MetaEditor: **File -> New -> Project** ตั้งชื่อ แล้วใช้ Add existing file เลือก `GoldTrendEA.mq5`
(ไฟล์ .mqproj เป็นของที่ MetaEditor สร้างเอง จึงไม่ได้ใส่มาให้)

## กลยุทธ์โดยย่อ

| ส่วน | รายละเอียด |
|------|-----------|
| เข้าไม้ | EMA 20 ตัด EMA 50 บนแท่งที่ปิดแล้ว + ราคาอยู่ฝั่งเดียวกับ EMA 200 + ADX >= 20 + +DI/-DI ตรงทิศ |
| SL / TP | 2 x ATR / 3 x ATR |
| Trailing | เริ่มเมื่อกำไร >= 1.5 x ATR ตามห่าง 1.5 x ATR |
| ขนาด lot | คำนวณจาก % ความเสี่ยงต่อไม้ (ค่าเริ่มต้น 1% ของ balance) |
| ตัวกรอง | สเปรดสูงสุด 60 points, ช่วงเวลา 07:00-20:00 เวลาเซิร์ฟเวอร์, หยุดเปิดไม้ใหม่ถ้าขาดทุนรายวัน >= 3% |
| จำนวนไม้ | 1 ไม้ต่อครั้ง |

## Input ที่ควรปรับก่อนใช้

- `InpMagic` เลข Magic ไม่ให้ซ้ำกับ EA ตัวอื่น
- `InpRiskPercent` ความเสี่ยงต่อไม้ (%)
- `InpStartHour` / `InpEndHour` **เวลาเซิร์ฟเวอร์ของโบรกเกอร์** ไม่ใช่เวลาไทย
- `InpMaxSpreadPts` สเปรดสูงสุด (หน่วย points) ทอง 2 digits: 60 points = $0.60
- `InpTF` timeframe ที่ใช้ส่งสัญญาณ (ค่าเริ่มต้น H1)

## แนวทางทดสอบ

1. Strategy Tester -> เลือก EA, สัญลักษณ์ทอง, H1, โหมด **Every tick based on real ticks**
2. ทดสอบย้อนหลังหลายปี และทดสอบช่วงที่ไม่ได้ใช้ปรับค่า (out-of-sample)
3. รันบนบัญชี **Demo** อย่างน้อยสองสามสัปดาห์
4. ขึ้นบัญชีจริงด้วยเงินก้อนเล็กก่อน

## คำเตือน

โค้ดชุดนี้เป็นตัวอย่างเพื่อการเรียนรู้ ยังไม่ได้ผ่านการคอมไพล์/ทดสอบกับข้อมูลจริง
การเทรดทองมีความเสี่ยงสูง ผลย้อนหลังไม่ได้รับประกันผลในอนาคต
